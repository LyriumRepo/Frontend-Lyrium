<?php

namespace Database\Seeders;

use App\Models\Category;
use Illuminate\Database\Seeder;

class CategorySeeder extends Seeder
{
    public function run(): void
    {
        $categories = [
            ['name' => 'Semillas', 'slug' => 'semillas', 'sort_order' => 1],
            ['name' => 'Fertilizantes', 'slug' => 'fertilizantes', 'sort_order' => 2],
            ['name' => 'Herramientas', 'slug' => 'herramientas', 'sort_order' => 3],
            ['name' => 'Suplementos', 'slug' => 'suplementos', 'sort_order' => 4],
            ['name' => 'Alimentos Orgánicos', 'slug' => 'alimentos-organicos', 'sort_order' => 5],
            ['name' => 'Cuidado Personal', 'slug' => 'cuidado-personal', 'sort_order' => 6],
            ['name' => 'Aceites Esenciales', 'slug' => 'aceites-esenciales', 'sort_order' => 7],
            ['name' => 'Productos Naturales', 'slug' => 'productos-naturales', 'sort_order' => 8],
        ];

        foreach ($categories as $cat) {
            Category::firstOrCreate(['slug' => $cat['slug']], $cat);
        }
    }
}