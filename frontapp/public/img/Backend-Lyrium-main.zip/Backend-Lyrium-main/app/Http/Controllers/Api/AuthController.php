<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Requests\LoginRequest;
use App\Http\Requests\RegisterCustomerRequest;
use App\Http\Requests\RegisterRequest;
use App\Http\Resources\UserResource;
use App\Models\Store;
use App\Models\User;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;

class AuthController extends Controller
{
    /**
     * POST /api/auth/login
     * Frontend envía: { email, password }
     * Responde: { success, token, user }
     */
    public function login(LoginRequest $request): JsonResponse
    {
        $credentials = $request->validated();

        // Buscar por email o username
        $user = User::where('email', $credentials['email'])
            ->orWhere('username', $credentials['email'])
            ->first();

        if (!$user || !Hash::check($credentials['password'], $user->password)) {
            return response()->json([
                'success' => false,
                'error' => 'Credenciales inválidas.',
            ], 401);
        }

        // Revocar tokens anteriores
        $user->tokens()->delete();

        $token = $user->createToken('auth-token')->plainTextToken;

        return response()->json([
            'success' => true,
            'token' => $token,
            'user' => new UserResource($user),
        ]);
    }

    /**
     * POST /api/auth/register
     * Frontend envía: { storeName, email, phone, password, ruc }
     * Crea usuario + tienda en status pending
     */
    public function register(RegisterRequest $request): JsonResponse
    {
        $data = $request->validated();

        $username = Str::slug($data['storeName'], '_');
        $baseUsername = $username;
        $counter = 1;
        while (User::where('username', $username)->exists()) {
            $username = $baseUsername . '_' . $counter++;
        }

        $user = User::create([
            'name' => $data['storeName'],
            'username' => $username,
            'email' => $data['email'],
            'nicename' => Str::slug($data['storeName']),
            'phone' => $data['phone'],
            'document_type' => 'RUC',
            'document_number' => $data['ruc'],
            'is_seller' => true,
            'password' => $data['password'],
        ]);

        $user->assignRole('seller');

        Store::create([
            'owner_id' => $user->id,
            'ruc' => $data['ruc'],
            'trade_name' => $data['storeName'],
            'corporate_email' => $data['email'],
            'slug' => Str::slug($data['storeName']),
            'status' => 'pending',
        ]);

        return response()->json([
            'success' => true,
            'message' => 'Registro exitoso. Tu tienda está pendiente de aprobación.',
        ], 201);
    }

    /**
     * POST /api/auth/register-customer
     * Frontend envía: { name, email, password }
     * Crea usuario con rol customer
     */
    public function registerCustomer(RegisterCustomerRequest $request): JsonResponse
    {
        $data = $request->validated();

        $username = Str::slug($data['name'], '_');
        $baseUsername = $username;
        $counter = 1;
        while (User::where('username', $username)->exists()) {
            $username = $baseUsername . '_' . $counter++;
        }

        $user = User::create([
            'name' => $data['name'],
            'username' => $username,
            'email' => $data['email'],
            'nicename' => Str::slug($data['name']),
            'password' => $data['password'],
        ]);

        $user->assignRole('customer');

        return response()->json([
            'success' => true,
            'message' => '¡Cuenta creada exitosamente! Ya puedes iniciar sesión.',
        ], 201);
    }

    /**
     * POST /api/auth/logout
     */
    public function logout(Request $request): JsonResponse
    {
        $request->user()->currentAccessToken()->delete();

        return response()->json(['success' => true]);
    }

    /**
     * GET /api/auth/validate
     * Valida el token actual y retorna el usuario
     */
    public function validateToken(Request $request): JsonResponse
    {
        return response()->json(new UserResource($request->user()));
    }

    /**
     * POST /api/auth/refresh
     * Rota el token actual por uno nuevo
     */
    public function refreshToken(Request $request): JsonResponse
    {
        $user = $request->user();
        $user->currentAccessToken()->delete();
        $token = $user->createToken('auth-token')->plainTextToken;

        return response()->json(['token' => $token]);
    }
}