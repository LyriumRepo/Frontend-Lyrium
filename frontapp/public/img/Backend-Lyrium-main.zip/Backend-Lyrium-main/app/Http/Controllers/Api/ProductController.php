<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Requests\StoreProductRequest;
use App\Http\Requests\UpdateProductRequest;
use App\Http\Resources\ProductResource;
use App\Models\Category;
use App\Models\Product;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Str;

class ProductController extends Controller
{
    /**
     * GET /api/products
     */
    public function index(Request $request): JsonResponse
    {
        $query = Product::with(['categories', 'mainAttributes', 'additionalAttributes']);

        // Seller solo ve sus productos
        $user = $request->user();
        if ($user && $user->is_seller && !$user->is_admin) {
            $store = $user->store;
            if ($store) {
                $query->where('store_id', $store->id);
            }
        } else {
            // Público/admin: solo aprobados (o todos si admin)
            if (!$user || !$user->is_admin) {
                $query->where('status', 'approved');
            }
        }

        // Filtros
        if ($search = $request->query('search')) {
            $query->where(function ($q) use ($search) {
                $q->where('name', 'like', "%{$search}%")
                  ->orWhere('description', 'like', "%{$search}%");
            });
        }

        if ($category = $request->query('category')) {
            $query->whereHas('categories', fn ($q) => $q->where('slug', $category));
        }

        if ($sticker = $request->query('sticker')) {
            $query->where('sticker', $sticker);
        }

        if ($request->query('inStock') === 'true') {
            $query->where('stock', '>', 0);
        }

        if ($status = $request->query('status')) {
            $query->where('status', $status);
        }

        $products = $query->orderBy('created_at', 'desc')->get();

        return response()->json(ProductResource::collection($products));
    }

    /**
     * GET /api/products/{id}
     */
    public function show(string $id): JsonResponse
    {
        $product = Product::with(['categories', 'mainAttributes', 'additionalAttributes'])
            ->findOrFail($id);

        return response()->json(new ProductResource($product));
    }

    /**
     * POST /api/products
     */
    public function store(StoreProductRequest $request): JsonResponse
    {
        $data = $request->validated();
        $user = $request->user();
        $store = $user->store;

        if (!$store) {
            return response()->json(['message' => 'No tienes una tienda registrada.'], 403);
        }

        $product = Product::create([
            'store_id' => $store->id,
            'name' => $data['name'],
            'slug' => Str::slug($data['name']) . '-' . Str::random(5),
            'description' => $data['description'] ?? '',
            'price' => $data['price'],
            'stock' => $data['stock'],
            'weight' => $data['weight'] ?? null,
            'dimensions' => $data['dimensions'] ?? null,
            'image' => $data['image'] ?? null,
            'discount_percentage' => $data['discountPercentage'] ?? null,
            'status' => 'pending_review', // Requiere aprobación admin
        ]);

        // Asociar categoría
        if (!empty($data['category'])) {
            $category = Category::where('slug', $data['category'])->first();
            if ($category) {
                $product->categories()->attach($category->id);
            }
        }

        // Crear atributos
        if (!empty($data['mainAttributes'])) {
            foreach ($data['mainAttributes'] as $attr) {
                $product->attributes()->create([
                    'type' => 'main',
                    'values' => $attr['values'] ?? [],
                ]);
            }
        }

        if (!empty($data['additionalAttributes'])) {
            foreach ($data['additionalAttributes'] as $attr) {
                $product->attributes()->create([
                    'type' => 'additional',
                    'values' => $attr['values'] ?? [],
                ]);
            }
        }

        $product->load(['categories', 'mainAttributes', 'additionalAttributes']);

        return response()->json(new ProductResource($product), 201);
    }

    /**
     * PUT /api/products/{id}
     */
    public function update(UpdateProductRequest $request, string $id): JsonResponse
    {
        $product = Product::findOrFail($id);
        $data = $request->validated();

        $updateData = [];
        if (isset($data['name'])) $updateData['name'] = $data['name'];
        if (isset($data['description'])) $updateData['description'] = $data['description'];
        if (isset($data['price'])) $updateData['price'] = $data['price'];
        if (isset($data['stock'])) $updateData['stock'] = $data['stock'];
        if (isset($data['image'])) $updateData['image'] = $data['image'];
        if (array_key_exists('sticker', $data)) $updateData['sticker'] = $data['sticker'];
        if (array_key_exists('discountPercentage', $data)) {
            $updateData['discount_percentage'] = $data['discountPercentage'];
        }

        $product->update($updateData);

        // Actualizar categoría
        if (isset($data['category'])) {
            $category = Category::where('slug', $data['category'])->first();
            if ($category) {
                $product->categories()->sync([$category->id]);
            }
        }

        // Actualizar atributos
        if (isset($data['mainAttributes'])) {
            $product->mainAttributes()->delete();
            foreach ($data['mainAttributes'] as $attr) {
                $product->attributes()->create([
                    'type' => 'main',
                    'values' => $attr['values'] ?? [],
                ]);
            }
        }

        if (isset($data['additionalAttributes'])) {
            $product->additionalAttributes()->delete();
            foreach ($data['additionalAttributes'] as $attr) {
                $product->attributes()->create([
                    'type' => 'additional',
                    'values' => $attr['values'] ?? [],
                ]);
            }
        }

        $product->load(['categories', 'mainAttributes', 'additionalAttributes']);

        return response()->json(new ProductResource($product));
    }

    /**
     * DELETE /api/products/{id}
     */
    public function destroy(string $id): JsonResponse
    {
        $product = Product::findOrFail($id);
        $product->delete();

        return response()->json(['success' => true]);
    }

    /**
     * PUT /api/products/{id}/stock
     */
    public function updateStock(Request $request, string $id): JsonResponse
    {
        $product = Product::findOrFail($id);

        $data = $request->validate([
            'quantity' => 'required|integer|min:0',
        ]);

        $product->update(['stock' => $data['quantity']]);
        $product->load(['categories', 'mainAttributes', 'additionalAttributes']);

        return response()->json(new ProductResource($product));
    }

    /**
     * PUT /api/products/{id}/status
     * Admin: aprobar o rechazar productos
     */
    public function updateStatus(Request $request, string $id): JsonResponse
    {
        $product = Product::findOrFail($id);

        $data = $request->validate([
            'status' => 'required|string|in:approved,rejected,pending_review',
            'reason' => 'nullable|string',
        ]);

        $product->update(['status' => $data['status']]);
        $product->load(['categories', 'mainAttributes', 'additionalAttributes']);

        return response()->json(new ProductResource($product));
    }
}
