<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class StoreProductRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'name' => 'required|string|min:3|max:200',
            'description' => 'nullable|string|max:5000',
            'price' => 'required|numeric|min:0',
            'stock' => 'required|integer|min:0',
            'category' => 'nullable|string',
            'image' => 'nullable|string',
            'weight' => 'nullable|numeric|min:0',
            'dimensions' => 'nullable|string|max:100',
            'discountPercentage' => 'nullable|numeric|min:0|max:100',
            'mainAttributes' => 'nullable|array',
            'mainAttributes.*.values' => 'array',
            'mainAttributes.*.values.*' => 'string',
            'additionalAttributes' => 'nullable|array',
            'additionalAttributes.*.values' => 'array',
            'additionalAttributes.*.values.*' => 'string',
        ];
    }
}
