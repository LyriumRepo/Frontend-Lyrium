<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class CategoryResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        return [
            'id' => $this->id,
            'name' => $this->name,
            'slug' => $this->slug,
            'parent' => $this->parent_id ?? 0,
            'description' => $this->description ?? '',
            'count' => $this->products_count ?? $this->products()->count(),
            'image' => $this->image ? [
                'id' => $this->id,
                'src' => $this->image,
                'name' => $this->name,
            ] : null,
            'children' => CategoryResource::collection($this->whenLoaded('children')),
        ];
    }
}