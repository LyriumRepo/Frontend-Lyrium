<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class ProductResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        return [
            'id' => (string) $this->id,
            'name' => $this->name,
            'category' => $this->categories->first()?->slug ?? '',
            'price' => (float) $this->price,
            'stock' => (int) $this->stock,
            'weight' => $this->weight ? (float) $this->weight : null,
            'dimensions' => $this->dimensions,
            'description' => $this->description ?? '',
            'image' => $this->image ?? '',
            'sticker' => $this->sticker,
            'discountPercentage' => $this->discount_percentage ? (float) $this->discount_percentage : null,
            'mainAttributes' => $this->mainAttributes->map(fn ($attr) => [
                'values' => $attr->values,
            ])->values()->all(),
            'additionalAttributes' => $this->additionalAttributes->map(fn ($attr) => [
                'values' => $attr->values,
            ])->values()->all(),
            'createdAt' => $this->created_at->toIso8601String(),
            'status' => $this->status,
            'store_id' => $this->store_id,
        ];
    }
}
